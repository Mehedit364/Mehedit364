<!---GitHub README --->
<!--MetaTag-->
<meta name="keywords" content="ARU,Aru Bomber,Mr.Aru, Itz Aru, Ariful Islam,aru github,Aru-Bomber,sms bomber">
<meta name="description" content="Iam a small programmer">
<div align="center">
<img align="center" alt="" src="images/aru_github_picture.png">
</div>


<div align="center">
    <img src="https://readme-typing-svg.herokuapp.com?color=tomato&size=50&center=true&vCenter=true&width=600&height=50&lines=Hi+👋,+I'm+Mehedit364;Web-Developer." />
</div>
<br>
<br>
<p><b>My name is Md Mehedi Hasan. I am Web designer, and I'm very passionate and dedicated to my work. With half years experience as a professional graphic designer, I have acquired the skills and knowledge necessary to make your project a success.</b></p>
<br>
<br>


`` ⚙️ GitHub Analytics``
<p align="center">
<a href="https://github.com/Mehedit364">
<img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api?username=Mehedit364&show_icons=true&theme=algolia&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api/top-langs/?username=Mehedit364&layout=compact&langs_count=10&theme=algolia"/>

<!-- [![Mehedit364's GitHub Activity Graph](https://activity-graph.herokuapp.com/graph?username=Mehedit364 &theme=react-dark)](Mehedit364) -->



</a>
</p>
<br>


`` ☺️ABOUT MEHEDI364 :  ``

<div align="left">
<br>
<div align="center">
<b> 🖥️ Iam a Student and A part time Programmer</b>
<br>
<br>
</div>
<ul>
<li>🇧🇩 Resident of Bangladesh</li>
<li>😇 Muslim </li>
<li>😒 Studying in a government college </li>
<li>😪 Love Sleeping </li>
<li>💔 Born Single </li>
<li>☹️ Aim: Become a software engineer</li>
</ul>
<br>
</div>



``😇 My Skills: ``
<div align="center">
  <img src="https://img.shields.io/badge/-HTML-f06529?style=for-the-badge&logo=html5&logoColor=e34c26&labelColor=282828">
  <img src="https://img.shields.io/badge/-CSS-264de4?style=for-the-badge&logo=css3&logoColor=2965f1&labelColor=282828">
<img src="https://img.shields.io/badge/-JAVASCRIPT-F0DB4F?style=for-the-badge&logo=javascript&logoColor=F0DB4F&labelColor=282828">
<img src="https://img.shields.io/badge/-JQUERY-78cff5?style=for-the-badge&logo=jquery&logoColor=0769ad&labelColor=282828">
  <img src="https://img.shields.io/badge/-BOOTSTRAP-563d7c?style=for-the-badge&logo=bootstrap&logoColor=563d7c&labelColor=282828">
<img src="https://img.shields.io/badge/-JSON-f85a40?style=for-the-badge&logo=json&logoColor=f85a40&labelColor=282828">
<br>
<br>
<br>
</div>



`` 📖 Trying To Learn: ``
<div align="center">
<img src="https://img.shields.io/badge/-PHP-787CB5?style=for-the-badge&logo=php&logoColor=787CB5&labelColor=282828">
<img src="https://img.shields.io/badge/-Python-4B8BBE?style=for-the-badge&logo=python&logoColor=306998&labelColor=282828">
<img src="https://img.shields.io/badge/-Android Development-3DDC84?style=for-the-badge&logo=android&logoColor=3DDC84&labelColor=282828">
  <img src="https://img.shields.io/badge/-NODE JS-3C873A?style=for-the-badge&logo=node.js&logoColor=68A063&labelColor=282828">
<img src="https://img.shields.io/badge/-REACT-61DBFB?style=for-the-badge&logo=react&logoColor=61DBFB&labelColor=282828">
  <img src="https://img.shields.io/badge/-SASS-cc6699?style=for-the-badge&logo=sass&logoColor=cc6699&labelColor=282828">
<img src="https://img.shields.io/badge/-MongoDB-3FA037?style=for-the-badge&logo=mongodb&logoColor=4DB33D&labelColor=282828">
  <img src="https://img.shields.io/badge/-MySQL-00758f?style=for-the-badge&logo=mysql&logoColor=f29111&labelColor=282828">
<img src="https://img.shields.io/badge/-SHELL-ED1C24?style=for-the-badge&logo=shell&logoColor=ED1C24&labelColor=FFD500">
  <img src="https://img.shields.io/badge/-GO-29BEB0?style=for-the-badge&logo=go&logoColor=29BEB0&labelColor=282828">
<br>
<br>
<br>
<br>
</div>






`` 📡 Get in Touch `` 
<br>

<a href="https://www.facebook.com/mehedi364" target="_blank"><img src="https://img.shields.io/badge/FACEBOOK-4267B2.svg?&style=flat-square&logo=facebook&logoColor=white" alt="LinkedIn"></a>
<a href="https://www.instagram.com/mehedit364" target="_blank"><img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?&style=flat-square&logo=instagram&logoColor=white" alt="Instagram"></a>
<a href="https://twitter.com/mehedit364" target="_blank"><img src="https://img.shields.io/badge/Twitter-%231DA1F2.svg?&style=flat-square&logo=twitter&logoColor=white" alt="Twitter"></a>
<a href="https://www.youtube.com/c/mehedi364" target="_blank"><img src="https://img.shields.io/badge/YouTube-FF0000.svg?&style=flat-square&logo=youtube&logoColor=white" alt="YouTube"></a>
<a href="https://mehedit364.xyz/" target="_blank"><img src="https://img.shields.io/badge/DEV-%230A0A0A.svg?&style=flat-square&logo=Chrome&logoColor=white" alt="Website"></a>
<a href="mailto: mehedit364@gmail.com" target="_blank"><img src="https://img.shields.io/badge/Email-BB001B.svg?&style=flat-square&logo=gmail&logoColor=white" alt="Gmail"></a>
<a href="https://github.com/mehedit364" target="_blank"><img src="https://img.shields.io/badge/GitHub-171515.svg?&style=flat-square&logo=github&logoColor=white" alt="Github"></a>



<p align="center">Made With ❤️ by <a href="https://www.facebook.com/mehedi364">Md Mehedi Hasan</a> </p>




<div align="center">
<a href="https://gist.github.com/mehedit364"><img src="https://profile-counter.glitch.me/{mehedit364}/count.svg" alt="Mehedit364 :: Visitor's Count" /></a>
</div>
